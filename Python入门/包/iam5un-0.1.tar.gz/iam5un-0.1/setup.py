from distutils.core import setup

setup(name="iam5un", version="0.1", py_modules=['sunmsg.recvmsg', 'sunmsg.sendmsg'])