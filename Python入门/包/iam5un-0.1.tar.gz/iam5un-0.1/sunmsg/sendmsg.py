def send_msg():
    print("this is sunmsg.sendmsg.send_msg()")